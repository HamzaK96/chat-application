### OAuth2 package

Inspired by [goauth2](https://code.google.com/p/goauth2)