package main

import (
	"testing"
)

// TestSomething is a place holder to make sure this package
// gets built / compiled when running tests.
//
// See the notes in main.go to see the example in action.
func TestSomething(t *testing.T) {}
