// General use authentication package for Go.
//
// To get started, visit the Gomniauth GitHub project
// homepage: https://github.com/stretchr/gomniauth
package gomniauth
