package main

/*

	This has moved to https://github.com/stretchr/gomniauth/tree/master/example/goweb

*/
