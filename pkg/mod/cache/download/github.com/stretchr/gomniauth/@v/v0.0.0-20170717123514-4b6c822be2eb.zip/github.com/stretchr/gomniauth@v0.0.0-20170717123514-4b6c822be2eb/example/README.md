## Examples

### Goweb example app

The [goweb/main.go](https://github.com/stretchr/gomniauth/blob/master/example/goweb/main.go) file is an example of how to implement Gomniauth with [Goweb](http://github.com/stretchr/goweb).

### net/http example app

The [nethttp/main.go](https://github.com/stretchr/gomniauth/blob/master/example/nethttp/main.go) file is an example of how to implement Gomniauth with minimal dependencies.

### Other examples

Please feel free to add your own examples and send us a pull request.
