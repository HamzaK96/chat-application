// A codec for handling JSONP encoding.
package jsonp
