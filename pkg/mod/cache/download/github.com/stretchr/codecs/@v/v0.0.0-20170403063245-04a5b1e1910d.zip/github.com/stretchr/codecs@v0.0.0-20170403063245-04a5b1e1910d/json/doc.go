// A codec for handling JSON encoding and decoding.
package json
