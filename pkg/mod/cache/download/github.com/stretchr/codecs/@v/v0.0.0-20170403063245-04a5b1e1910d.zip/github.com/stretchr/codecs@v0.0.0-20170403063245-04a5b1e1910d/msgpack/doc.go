// A codec for handling msgpack encoding and decoding.
package msgpack
