// A codec for handling BSON encoding and decoding
package bson
