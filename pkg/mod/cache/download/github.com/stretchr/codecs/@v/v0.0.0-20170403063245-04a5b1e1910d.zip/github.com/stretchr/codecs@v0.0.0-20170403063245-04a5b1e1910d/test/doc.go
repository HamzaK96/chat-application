// test package provides object useful for testing code that relies on Codecs.
package test
