// The csv package contains a codec for talking CSV (comma separated values).
package csv
