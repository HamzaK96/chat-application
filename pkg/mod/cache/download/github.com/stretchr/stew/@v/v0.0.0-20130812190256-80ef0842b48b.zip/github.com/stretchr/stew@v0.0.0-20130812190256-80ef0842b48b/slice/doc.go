// Slice provides high-performance slice management utilities.
package slice
