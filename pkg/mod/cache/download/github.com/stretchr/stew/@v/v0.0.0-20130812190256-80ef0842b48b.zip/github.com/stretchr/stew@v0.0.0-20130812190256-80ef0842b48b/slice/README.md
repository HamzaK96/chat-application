slice
=====

Slice provides lovely helpful slice methods for Go

  * This project is in its very early stages, and will be built out as needed.