strings
=======

High-performance string management and manipulation capabilities.

  * Read the [API Documentation](http://godoc.org/github.com/stretchr/stew/strings)
  