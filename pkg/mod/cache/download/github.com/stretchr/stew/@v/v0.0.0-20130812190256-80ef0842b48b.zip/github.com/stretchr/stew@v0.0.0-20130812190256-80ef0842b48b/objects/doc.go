// Objects package adds more functionality to maps and other data objects.
package objects
