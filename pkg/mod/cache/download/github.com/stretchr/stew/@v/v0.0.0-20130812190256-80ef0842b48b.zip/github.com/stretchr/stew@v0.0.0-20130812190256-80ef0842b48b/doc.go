// stew is a delicious mix of helpful and handy utilities for making writing Go code even easier.
package stew
